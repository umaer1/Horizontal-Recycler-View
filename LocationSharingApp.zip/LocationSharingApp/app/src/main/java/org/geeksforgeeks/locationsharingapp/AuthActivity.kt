package org.geeksforgeeks.locationsharingapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.animation.Animator
import android.animation.AnimatorInflater
import android.annotation.SuppressLint
import android.widget.Button

class AuthActivity : AppCompatActivity() {

    // Variable to hold the animator instance so we can start/stop it later.
    private var pulseAnimator: Animator? = null

    @SuppressLint("ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)


        // 1. Find the Button View by its ID
        val registerBtn = findViewById<Button>(R.id.registerBtn)

        // 2. Load the animation definition from the XML resource file
        // The resource ID R.drawable.pulse_animation refers to the XML we created.
        pulseAnimator = AnimatorInflater.loadAnimator(this, R.anim.pulse_animation)

        // 3. Set the button as the target for the animation
        pulseAnimator?.setTarget(registerBtn)

        // 4. Start the animation!
        pulseAnimator?.start()

        // Optional: Set up a click listener for the button
        registerBtn.setOnClickListener {
            // Stop the animation when the user clicks to register
            pulseAnimator?.cancel()
            // Add your registration logic here
        }
    }

    // BEST PRACTICE: Manage the animation lifecycle

    override fun onPause() {
        super.onPause()
        // Stop the animation to save battery when the screen is hidden
        pulseAnimator?.pause()
    }

    override fun onResume() {
        super.onResume()
        // Restart the animation when the user returns to the screen
        pulseAnimator?.start()
    }
}